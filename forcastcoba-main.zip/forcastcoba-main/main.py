import os
import streamlit as st
import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import load_model
import yfinance as yf
from datetime import datetime, timedelta
import matplotlib.pyplot as plt

def create_sequences(data, seq_length=60):
    X = []
    y = []
    for i in range(seq_length, len(data)):
        X.append(data[i-seq_length:i, 0])
        y.append(data[i, 0])
    return np.array(X), np.array(y)

def forecast(model, input_data, num_units, units_type, seq_length=60):
    if units_type == "Bulan":
        steps = 30 * num_units
    else: # units_type == "years"
        steps = 365 * num_units

    future_predictions = []
    current_input = input_data[-seq_length:].reshape(1, seq_length, 1)

    for _ in range(steps):
        prediction = model.predict(current_input)[0][0]
        future_predictions.append(prediction)
        current_input = np.roll(current_input, -1)
        current_input[0, -1, 0] = prediction

    return future_predictions

def main():
    st.set_page_config(page_title="Aplikasi Prediksi Harga Saham", layout="centered")
    st.title("Aplikasi Prediksi Harga Saham Perbankan")
    st.write("Selamat Datang Pada Aplikasi Prediksi Harga Saham.")
    st.write("Silahkan Pilih Saham yang Ingin dilakukan Prediksi.")

    pilihan_saham = ['BBCA.JK', 'BBRI.JK', 'BBNI.JK']
    stock_ticker = st.selectbox("Pilih Saham:", pilihan_saham)

    start_date = pd.to_datetime("2017-01-01")
    end_date = pd.to_datetime("2021-12-31")

    df = yf.download(stock_ticker, start=start_date, end=end_date)
    df.dropna(inplace=True)

    st.write("Data Saham Dari 1 Januari 2017 - 31 Desember 2021")
    st.dataframe(df.style.highlight_max(axis=0))

    st.write("Grafik Saham Dari 1 Januari 2017 - 31 Desember 2021")
    st.line_chart(df['Close'])

    units_type = st.radio("Pilih Waktu Prediksi:", ("Bulan", "Tahun"))

    if units_type == "Bulan":
        num_units = st.slider("Rentang Waktu Bulanan (1-12 Bulan):", min_value=1, max_value=12, value=1)
    else: # units_type == "years"
        num_units = st.slider("Rentang Waktu Tahunan (1-3 Tahun):", min_value=1, max_value=3, value=1)  

    if st.button("Lakukan Prediksi"):
        scaler = MinMaxScaler()
        scaled_data = scaler.fit_transform(df['Close'].values.reshape(-1,1))

        if units_type == "Bulan":
            model_path = f"{stock_ticker.replace('.JK', '')}_model_bulanan.h5"
        else:
            model_path = f"{stock_ticker.replace('.JK', '')}.h5"
            
        if not os.path.isfile(model_path):
            st.error(f"Model Tidak Ditemukan {stock_ticker}. Harap pastikan file model {model_path} itu ada.")
            return
        
        model = load_model(model_path)

        future_predictions = forecast(model, scaled_data, num_units, units_type)
        future_predictions = scaler.inverse_transform(np.array(future_predictions).reshape(-1, 1))

        future_dates = pd.date_range(start=df.index[-1] + timedelta(days=1), periods=len(future_predictions), freq='D')
        future_df = pd.DataFrame(data=future_predictions, index=future_dates, columns=['Predictions'])

        st.write(f"Harga Prediksi Menunjukkan: {future_predictions[-1][0]} pada tanggal {future_dates[-1].strftime('%Y-%m-%d')}")  # <-- Update this line

        st.write("Grafik Saham Setelah Dilakukan Prediksi")
        chart_data = pd.concat([df['Close'], future_df['Predictions']], axis=1)
        st.line_chart(chart_data)

        fig, ax = plt.subplots(figsize=(10, 5))

        chart_data.plot(ax=ax)
        ax.set_ylabel('Close Price')

        for year in range(start_date.year, end_date.year + 2):
            ax.axvline(pd.to_datetime(f'{year}-01-01'), color='red', linestyle='--', lw=1)

        st.write("Grafik Saham Setelah Dilakukan Prediksi (dengan garis vertikal di awal tahun)")
        st.pyplot(fig)

if __name__ == "__main__":
    main()